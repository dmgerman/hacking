const EXPORTED_SYMBOLS = ['GM_constants'];

const GM_constants = {
  'directoryMask': parseInt('750', 8),
  'fileMask': parseInt('640', 8),
};
