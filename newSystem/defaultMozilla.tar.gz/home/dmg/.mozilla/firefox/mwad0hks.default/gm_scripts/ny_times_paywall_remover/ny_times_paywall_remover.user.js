// ==UserScript==
// @name           NY Times Paywall Remover
// @description    Removes the NY Times pay wall.
// @namespace      http://www.aintaer.com/Projects
// @include        http*://nytimes.com/*
// @include        http*://*.nytimes.com/*
// @version        1.0
// ==/UserScript==
var maxTimes=10, caughtEvents = ["load","onload","keydown"];

function findElem(id) {
	return document.getElementById(id);
}

function removeEl(el) {
	el.parentNode.style.display="none";
	GM_log("Overlay hidden");
}

function wait(check, callback){
  if (check()) callback()
  else window.setTimeout(wait, 300, check, callback);
}

function watchForElem(id) {
	wait(
		function() {return findElem(id)},
		function() {removeEl(findElem(id))}
	);
}

// Watching for NYT to grab keypresses, canceling it
wait(
	function(){
		document.wrappedJSObject.onkeypress = null;
		document.body.wrappedJSObject.ontouchmove = null;
		return (--maxTimes==0);
	},function(){}
);
// Hide the overlays and allow scrolling.
if (window.location.search.indexOf("gwh=")>-1) {
	watchForElem('gatewayCreative');
	GM_addStyle("body {overflow:scroll !important}");
}
// Prevent NYT from listening to certain events, see caughtEvents
var delayedEventListener = unsafeWindow.addEventListener;
unsafeWindow.addEventListener = function(ev,func,bubble) {
	var found = false;
	for (var i=caughtEvents.length-1;i>=0;--i)
		found |= (caughtEvents[i]==ev);
	if (found) GM_log("Blocked "+ev);
	else delayedEventListener(ev,func,bubble);
};
// Steal the generated callback function to do nothing
delayedEventListener("load",function() {
	var callbackRE = new RegExp("^\\w"+
		String((new Date()).getTime()).slice(0,-5));
	for (var i in unsafeWindow) {
		if (callbackRE.test(i)) unsafeWindow[i] = function(){};
	}
},false);
// Try to prevent loading of gwy.js
unsafeWindow.NYTD.Hosts.jsHost="//xxx.nytimes.com";
